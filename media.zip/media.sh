#!/bin/bash

cat >/opt/media/moniter.conf<<EOF
[main]
fifo=turnserver_fifo
run=/opt/media/turnserver -i 192.168.70.82 -p 18888 -n 217.174.229.22 -o 19999  -T 60 -R 600 -w 655360
pname=turnserver
EOF
